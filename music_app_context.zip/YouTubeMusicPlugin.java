package com.prakhar.sonic;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerFuture;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import okhttp3.*;
import org.json.*;
import java.io.IOException;

@CapacitorPlugin(
    name = "YouTubeMusic",
    permissions = {
        @Permission(strings = { Manifest.permission.GET_ACCOUNTS }, alias = "accounts")
    }
)
public class YouTubeMusicPlugin extends Plugin {

    private static final OkHttpClient client = new OkHttpClient();

    private String getGoogleAuthToken() {
        try {
            // Check permission
            if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.GET_ACCOUNTS)
                    != PackageManager.PERMISSION_GRANTED) {
                android.util.Log.e("YouTubeMusic", "GET_ACCOUNTS permission not granted");
                return null;
            }

            AccountManager am = AccountManager.get(getContext());
            Account[] accounts = am.getAccountsByType("com.google");
            android.util.Log.d("YouTubeMusic", "Google accounts found: " + accounts.length);

            if (accounts.length == 0) return null;

            // Log account email
            android.util.Log.d("YouTubeMusic", "Using account: " + accounts[0].name);

            AccountManagerFuture<android.os.Bundle> future = am.getAuthToken(
                accounts[0],
                "oauth2:https://www.googleapis.com/auth/youtube",
                null, getActivity(), null, null
            );
            android.os.Bundle bundle = future.getResult();
            String token = bundle.getString(AccountManager.KEY_AUTHTOKEN);
            android.util.Log.d("YouTubeMusic", "Token length: " + (token != null ? token.length() : 0));
            return token;
        } catch (Exception e) {
            android.util.Log.e("YouTubeMusic", "Auth token error: " + e.getMessage());
            return null;
        }
    }

    @PluginMethod
    public void getStreamUrl(PluginCall call) {
        String videoId = call.getString("videoId");
        if (videoId == null) {
            call.reject("videoId is required");
            return;
        }

        android.util.Log.d("YouTubeMusic", "getStreamUrl called for videoId: " + videoId);

        new Thread(() -> {
            try {
                String token = getGoogleAuthToken();
                android.util.Log.d("YouTubeMusic", "Auth token: " + (token != null ? "YES (" + token.length() + " chars)" : "NO"));

                String streamUrl = fetchStreamUrl(videoId, token);
                if (streamUrl != null) {
                    JSObject result = new JSObject();
                    result.put("streamUrl", streamUrl);
                    call.resolve(result);
                } else {
                    call.reject("Could not get stream URL");
                }
            } catch (Exception e) {
                android.util.Log.e("YouTubeMusic", "Error: " + e.getMessage());
                call.reject("Error: " + e.getMessage());
            }
        }).start();
    }

    private String fetchStreamUrl(String videoId, String token) throws IOException, JSONException {
        String url = "https://music.youtube.com/youtubei/v1/player?prettyPrint=false";

        JSONObject clientObj = new JSONObject();
        clientObj.put("clientName", "ANDROID_MUSIC");
        clientObj.put("clientVersion", "6.21.52");
        clientObj.put("androidSdkVersion", 30);
        clientObj.put("hl", "en");
        clientObj.put("gl", "IN");
        clientObj.put("utcOffsetMinutes", 330);

        JSONObject contextObj = new JSONObject();
        contextObj.put("client", clientObj);

        JSONObject contentPlaybackContext = new JSONObject();
        contentPlaybackContext.put("signatureTimestamp", "20157");
        JSONObject playbackContext = new JSONObject();
        playbackContext.put("contentPlaybackContext", contentPlaybackContext);

        JSONObject bodyObj = new JSONObject();
        bodyObj.put("videoId", videoId);
        bodyObj.put("context", contextObj);
        bodyObj.put("playbackContext", playbackContext);

        Request.Builder requestBuilder = new Request.Builder()
            .url(url)
            .post(RequestBody.create(bodyObj.toString(), MediaType.parse("application/json; charset=utf-8")))
            .addHeader("Content-Type", "application/json")
            .addHeader("User-Agent", "com.google.android.apps.youtube.music/6.21.52 (Linux; U; Android 11; en_IN; Pixel 5; Build/RQ3A.210805.001+A1) gzip")
            .addHeader("X-Goog-Api-Format-Version", "1")
            .addHeader("X-YouTube-Client-Name", "21")
            .addHeader("X-YouTube-Client-Version", "6.21.52");

        if (token != null) {
            requestBuilder.addHeader("Authorization", "Bearer " + token);
            requestBuilder.addHeader("X-Goog-AuthUser", "0");
        }

        try (Response response = client.newCall(requestBuilder.build()).execute()) {
            String responseBody = response.body().string();
            android.util.Log.d("YouTubeMusic", "Response code: " + response.code());

            if (!response.isSuccessful()) return null;

            JSONObject data = new JSONObject(responseBody);
            JSONObject playabilityStatus = data.optJSONObject("playabilityStatus");
            String status = playabilityStatus != null ? playabilityStatus.optString("status") : "UNKNOWN";
            android.util.Log.d("YouTubeMusic", "Playability status: " + status);

            if (!"OK".equals(status)) return null;

            JSONObject streamingData = data.optJSONObject("streamingData");
            if (streamingData == null) return null;

            JSONArray formats = streamingData.optJSONArray("adaptiveFormats");
            if (formats == null) formats = streamingData.optJSONArray("formats");
            if (formats == null) return null;

            String bestUrl = null;
            int bestBitrate = 0;

            for (int i = 0; i < formats.length(); i++) {
                JSONObject format = formats.getJSONObject(i);
                String mimeType = format.optString("mimeType", "");
                String formatUrl = format.optString("url", "");
                int bitrate = format.optInt("bitrate", 0);

                if (mimeType.startsWith("audio/") && !formatUrl.isEmpty() && bitrate > bestBitrate) {
                    bestBitrate = bitrate;
                    bestUrl = formatUrl;
                }
            }

            android.util.Log.d("YouTubeMusic", "Best URL found: " + (bestUrl != null ? "YES" : "NO"));
            return bestUrl;
        }
    }
}
